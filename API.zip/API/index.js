'use strict'
/* eslint-env node , es6 */

// Import le paquet express 
const express = require('express')

const PORT = 6300

// Créé une application express
const app = express()

// Importer la logique de la page d'accueil
const genererPageAccueil = require('./pages/index.get.js')


// Ecouter la méthode GET et la route '/'
app.get('/', async(req, res) => {
    const indexHtml =await genererPageAccueil()

    res.send(indexHtml)
})
// Retourne les images 
// Retourne les styles 
app.use('/styles', express.static('C:/'))
app.use('/images', express.static('C:/'))

// Démarrer le serveur et écouter un port donné 
 app.listen(PORT, () => {
    console.log('Serveur démarré : http://localhost:${PORT}')
 })

 