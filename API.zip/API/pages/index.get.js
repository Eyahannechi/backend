'use strict'
/* eslint-env node , es6 */

const { readFile } = require('fs')
const { promisify } = require ('util')
const readFileAsync = promisify(readFile)
const READ_OPTIONS = { encoding: 'UTF-8' }
const INDEX_URL = 'c:/'

module.exports = async() => {
    // Opération
    // Récupérer le contenu  du fichier html index.html
  const contenu = await readFileAsync(INDEX_URL, READ_OPTIONS)

    // Retourner la page HTML
    return contenu
}